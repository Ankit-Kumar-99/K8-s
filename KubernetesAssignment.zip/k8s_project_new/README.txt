1). You need to write required yaml files for this service.

2). You need to create jar for this service first and then create dockerfile for it.

3). After that to deploy this service in kubernetes you need to install minikube in your local or if you have any cloud platform account then it is also fine.

4). You can access this application on any port you want to (it's your choice).

5). This application is deploying tomcat server in kubernetes.
